#include "printk.h"

extern void test();

int start_kernel()
{
    printk("2024");
    printk(" ZJU Operating System\n");

    test();
    return 0;
}
