#define SYS_WRITE   64
#define SYS_GETPID  172
#define SYS_CLONE 220
