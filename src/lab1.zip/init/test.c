#include "printk.h"
#include "defs.h"

void test() {
    int i = 0;
    uint64_t data_in = 0x12345678;
    csr_write(sscratch, data_in);
    uint64_t data_out;
    data_out = csr_read(sscratch);
    if (data_out == data_in)
        printk("success!\nread=write=0x%lx\n", data_out);
    else
        printk("failed!\nread=0x%lx, write=0x%lx\n", data_out, data_in);

    while (1)
    {
        if ((++i) % 100000000 == 0)
        {
            printk("kernel is running!\n");
            i = 0;
        }
    }
}